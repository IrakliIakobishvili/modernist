var http = require('http');
var url = require('url');
var fs = require('fs');


http.createServer(function (req, res) {

    if(req.url.indexOf('.html') != -1){ //req.url has the pathname, check if it conatins '.html'

      fs.readFile(__dirname + './public/index.html', function (err, data) {
        if (err) console.log(err);
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
      });

    }

    if(req.url.indexOf('.js') != -1){ //req.url has the pathname, check if it conatins '.js'

      fs.readFile(__dirname + '/public/js/script.js', function (err, data) {
        if (err) console.log(err);
        res.writeHead(200, {'Content-Type': 'text/javascript'});
        res.write(data);
        res.end();
      });

    }

    if(req.url.indexOf('.css') != -1){ //req.url has the pathname, check if it conatins '.css'

      fs.readFile(__dirname + '/public/css/style.css', function (err, data) {
        if (err) console.log(err);
        res.writeHead(200, {'Content-Type': 'text/css'});
        res.write(data);
        res.end();
      });

    }

}).listen(3000);


// function renderHTML(path, response) {
//     fs.readFile(path, null, function(error, data) {
//         if (error) {
//             response.writeHead(404);
//             response.write('File not found!');
//         } else {
//             response.write(data);
//         }
//         response.end();
//     });
// }

//     http.createServer(function(request, response) {
//       response.writeHead(200, {'Content-Type': 'text/html'});

//       var path = url.parse(request.url).pathname;
//       switch (path) {
//           case '/':
//               renderHTML('./index.html', response);
//               break;
//           case '/login':
//               renderHTML('./login.html', response);
//               break;
//           default:
//               response.writeHead(404);
//               response.write('Route not defined');
//               response.end();
//       }

//   }).listen(3000);





// const express = require('express');
// var path = require('path');
// const app = express();

// app.get('/', (req, res) => {
//   res.send('An alligator approaches!');
// });

// app.get('/gallery', (req, res) => {
//   res.sendFile(path.join(__dirname + '/gallery.html'));
// });

// app.listen(3000)