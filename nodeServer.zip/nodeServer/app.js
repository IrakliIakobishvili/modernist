var express = require("express");
var app     = express();
var path    = require("path");


app.use(express.static('public'));

app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/public/index.html'));
});

app.get('/home',function(req,res){
  res.sendFile(path.join(__dirname+'/public/index.html'));
});

app.get('/style-demo',function(req,res){
  res.sendFile(path.join(__dirname+'/public/style-demo.html'));
});

app.get('/full-width',function(req,res){
  res.sendFile(path.join(__dirname+'/public/full-width.html'));
});

app.get('/dropdown',function(req,res){
  res.sendFile(path.join(__dirname+'/public/dropdown.html'));
});

app.get('/portfolio',function(req,res){
  res.sendFile(path.join(__dirname+'/public/portfolio.html'));
});

app.get('/gallery',function(req,res){
  // res.sendFile('public/gallery.html');
  res.sendFile(path.join(__dirname+'/public/gallery.html'));
});

app.get('*', function(req, res){
  res.sendFile(path.join(__dirname+'/public/404.html')); // error 404
});

app.listen(3000);

console.log("Running at Port 3000");